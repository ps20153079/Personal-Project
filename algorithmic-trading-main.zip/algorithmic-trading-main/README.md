# Algorithmic Trading with Python
### To copy files to your computer run at the command line (requires git to be installed first [https://git-scm.com](https://git-scm.com)):
`git clone https://github.com/mjmacarty/algorithmic-trading` 

### After cloning to set up your environment run at the command line:
`pip install -r requirements.txt`